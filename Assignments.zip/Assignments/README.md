# Aave V2 Credit Scoring using Unsupervised Learning (KMeans)

This project builds an unsupervised machine learning model to assign a credit score (0–1000) to wallets interacting with the Aave V2 DeFi protocol. The scoring is based on past transaction behavior such as deposits, borrows, repayments, redemptions, and liquidations.

##  Objective

To identify responsible vs. risky wallet behaviors by analyzing 100K DeFi transactions and generating a transparent credit scoring system.

##  Input

- Raw JSON data of 100K transaction-level events (`user-wallet-transactions.json`)
- Actions include: `deposit`, `borrow`, `repay`, `redeemunderlying`, `liquidationcall`

##  Model Used

- **KMeans Clustering** (Unsupervised Learning)
- Wallets are clustered based on standardized features
- Clusters are ranked based on positive behavior (e.g. repays > borrows)
- Each cluster is mapped to a score range from **0 to 1000**

##  Output

- `wallet_scores.csv`: Contains each wallet with assigned `credit_score` and cluster ID

##  Tools

- Python, Pandas, Scikit-Learn, Matplotlib, Seaborn, unsupervised (Kmeans , Elbow )

##  Files

- `Aave_Credit_Scorings.ipynb`: Complete Jupyter notebook with code
- `wallet_scores.csv`: Wallet-wise scores
- `README.md`: Project overview (this file)
- `analysis.md`: Score-based analysis (see below)


---