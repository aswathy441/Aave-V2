#  Credit Score Analysis of Wallets

After clustering and scoring, the distribution of wallet credit scores shows clear patterns of responsible vs. risky behaviors.

## Credit Score Buckets

| Score Range | Wallet Count |
|-------------|---------------|
| 0–100       | Many wallets with liquidations, no repayments |
| 100–200     | Infrequent activity, no repays or redemptions |
| 200–400     | Moderate use of borrow/repay, no liquidations |
| 400–700     | Frequent deposit/repay activity, few borrows |
| 700–1000    | Highly active, regular deposits, repays, no liquidations |

##  Low Score Wallets Behavior (0–200)
- Frequent borrows without repays
- High liquidation calls
- Minimal engagement or one-time interaction

##  High Score Wallets Behavior (700–1000)
- Consistent deposits and repayments
- Multiple assets interacted with
- Active for many days, showing responsible DeFi usage

---
